It is a Virtual Room creation app, to enable a close group of people to join and modify the room ,
for party creation or music sharing, etc.

This app enables to create a Virtual Room, modify it(delete if required), and generate a unique code upon creation
of the room, which is then required to join the respective room by the required members.

This app has been specially designed as a Music Sharing Group App, to enable users to create a Virtual Room
 so that other members can be added to that and assign some privileges.
